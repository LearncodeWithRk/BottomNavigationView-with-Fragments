package in.xtremeworkplace.xtremeworkplace.home;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import androidx.fragment.app.Fragment;


import android.os.Bundle;
import android.view.MenuItem;


import com.google.android.material.bottomnavigation.BottomNavigationView;


import in.xtremeworkplace.xtremeworkplace.R;
import in.xtremeworkplace.xtremeworkplace.fragment.homeFragment;
import in.xtremeworkplace.xtremeworkplace.fragment.how_to_Fragment;
import in.xtremeworkplace.xtremeworkplace.fragment.serviceFragment;
import in.xtremeworkplace.xtremeworkplace.fragment.web_design_Fragment;

public class Home_page extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);



        //loading the default fragment
        loadFragment(new homeFragment());

        //getting bottom navigation view and attaching the listener
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(this);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;

        switch (item.getItemId()) {
            case R.id.home:
                fragment = new homeFragment();
                break;

            case R.id.how_to:
                fragment = new how_to_Fragment();
                break;


            case R.id.service:
                fragment = new serviceFragment();
                break;

            case R.id.web_design:
                fragment = new web_design_Fragment();
                break;
        }

        return loadFragment(fragment);
    }

    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }
}